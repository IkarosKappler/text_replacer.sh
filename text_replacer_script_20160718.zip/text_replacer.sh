#!/bin/bash

# find . -type f -exec sed -i 's/foo/bar/g' {} +

#!/bin/bash
#
# This script 'compiles' the javascript files and packs them into one single file.
#
#
# Version >= 1.0.1 requires yui-compressor to be installed.
# Install with
#  apt-get install yui-compressor
#
#
# @author   Ikaros Kappler
# @date     2015-05-27
# @modified 2015-07-08
# @version  1.0.1


_RED='\033[0;31m'
_GREEN='\033[0;32m'
_PURPLE='\033[0;35m'
_NC='\033[0m'

echo -e "${_PURPLE}This script replaces STRINGA by STRINGB i your passed file.${_NC}"
if [ $# -lt 4 ]; then
    echo -e "[${_RED}Error${_NC}] Please pass: <pattern> <replacement> <filelist>";
    echo -e "        Example: ${_GREEN}${0##*/} \"foo\" \"bar\" filelist.txt${_NC}"
    echo -e "        "
    exit 1;
fi

pattern=$1
replacement=$2
filelist=$3
outfile=$4

if [ ! -f "$filelist" ]; then
	echo "Filelist file '$filelist' not found."
	exit 1
fi


line_no=1
while read line
do
    # Trim line:
    var="${line#"${line%%[![:space:]]*}"}"   # remove leading whitespace characters
    var="${line%"${line##*[![:space:]]}"}"   # remove trailing whitespace characters

    # Check if line is not empty
    if [ ! -z "$line" -a "$line"!=" " ]; then

		# Check if line is no comment (beginning with ';')
		if [[ ${line:0:1} != ';' ]]; then

		    # Check if file exists
		    #if [ ! -f "$line" ]; then
			#	echo "Error: file $line not found."
			#	exit 1
		    #elif [[ "$line" =~ ' ' ]]; then   # Check if line contains whitespace
			#	files+=("\"$line\"")
		    #else
		    	#entry=$(echo $line | tr ":" "\n")
		    	entry=(${line//:/ })
		    	echo "infile=${entry[0]}";
		    	echo "outfile=${entry[1]}";
		    	infile=${entry[0]};
		    	outfile=${entry[1]};

		    	if [ ! -f $infile ]; then
		    		echo "Error: file '$infile' not found."
		    		exit 1;
		    	fi

		    	echo "Running 'sed \"s/$pattern/$replacement/g\" $infile'"
		    	sed "s/$pattern/$replacement/g" $infile > $outfile

				#files+=($line);
		    #fi
		fi
	
    fi
    line_no=`expr $line_no + 1`;
done < $filelist


