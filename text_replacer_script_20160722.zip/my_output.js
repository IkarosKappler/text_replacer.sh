This is the {INPUT} file.
